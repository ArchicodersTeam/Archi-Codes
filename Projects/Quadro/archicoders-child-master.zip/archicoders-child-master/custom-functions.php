<?php

function cs_variations_info_by_product($product,$wl_product){
    $variation_data = $product->is_type( 'variation' ) ? wc_get_product_variation_attributes( $product->get_id() ) : array();
    if(empty($wl_product['meta'])) $wl_product['meta'] = $wl_product['variation'];
    foreach ( $variation_data as $name => $value ) {
        if ( '' === $value ) {
            // Could be any value that saved to a custom meta.
            if ( array_key_exists( 'meta', $wl_product ) && array_key_exists( $name, $wl_product['meta'] ) ) {
                $value = $wl_product['meta'][ $name ];
            } else {
                continue;
            }
        }
        $taxonomy = wc_attribute_taxonomy_name( str_replace( 'attribute_pa_', '', urldecode( $name ) ) );

        // If this is a term slug, get the term's nice name.
        if ( taxonomy_exists( $taxonomy ) ) {
            $term = get_term_by( 'slug', $value, $taxonomy ); // @codingStandardsIgnoreLine WordPress.VIP.RestrictedFunctions.get_term_by
            if ( ! is_wp_error( $term ) && $term && $term->name ) {
                $value = $term->name;
            }
            $label = wc_attribute_label( $taxonomy );

            // If this is a custom option slug, get the options name.
        } else {
            $value              = apply_filters( 'woocommerce_variation_option_name', $value );
            $product_attributes = $product->get_attributes();
            $_name              = str_replace( 'attribute_', '', $name );
            if ( isset( $product_attributes[ $_name ] ) ) {
                $label = wc_attribute_label( $_name, $wl_product['data'] );
            } else {
                $label = $name;
            }
        }
        if ( '' === $value || wc_is_attribute_in_product_name( $value, is_callable( array(
                $product,
                'get_name'
            ) ) ? $product->get_name() : $product->get_title() ) ) {
            continue;
        }
        $item_data[] = array(
            'key'   => $label,
            'value' => $value,
            'price' => Iconic_WAS_Fees::get_fees_by_attribute($wl_product['product_id'],str_replace( 'attribute_', '', $name ))[$term->slug]
        );
    }
    return $item_data;
}
function cs_display_product_image($product_id,$attributes = array(),$product_url){
    $image_ids = Iconic_WPC::get_image_ids_by_attributes($product_id,$attributes);
    $image_size = Iconic_PC_Product::get_image_size( 'single' );
    ob_start();
    if ( ! empty( $image_ids ) ) { ?>
        <a href="<?php echo $product_url;?>" class="cs_iconic-pc-image-wrap iconic-pc-image-wrap" data-iconic_pc_product_id="<?php echo esc_attr( $product_id ); ?>" style="width: 100%;height: auto;position: relative;display: block;">
            <?php $z_index = 10; foreach ( $image_ids as $attribute => $image_id ) {
                $image = wp_get_attachment_image_src( $image_id, $image_size);
                ?>
                <div class="iconic-pc-image iconic-pc-image--<?php echo esc_attr( $attribute ); ?>" style="position: absolute;top: 50%;transform: translate(0,-50%);z-index: <?php echo $z_index; ?>;">
                    <?php if(!empty($image)): ?>
                        <img src="<?php echo $image[0]; ?>">
                    <?php endif; ?>
                </div>
                <?php $z_index = $z_index + 10; } ?>
        </a>
    <?php }
    return ob_get_clean();
}