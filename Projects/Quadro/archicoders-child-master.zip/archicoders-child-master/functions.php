<?php
/**
 * Theme functions and definitions
 *
 * @package ArchicodersHelloElementorChild
 */

/**
 * Load child theme css and optional scripts
 *
 * @return void
 */
function archicoders_hello_elementor_child_enqueue_scripts() {
	wp_enqueue_style(
		'hello-elementor-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		[
			'archicoders-elementor-theme-style',
		],
		'1.0.0'
	);
}
add_action( 'wp_enqueue_scripts', 'archicoders_hello_elementor_child_enqueue_scripts', 20 );


add_action( 'wp_footer', 'custom_script' );
function custom_script() {
?>
<script>
	const all = document.querySelector('.variations tr:has(td):has(select:not(#pa_style))');
	function clickMe(elem) {
		jQuery(function($) {
		    $(document).ready(function() {
		        $( elem ).click();
		    });
		});
	}
</script>
<?php
	function whatAttr($attrName) {
		global $product;
		$attributes = $product->get_attributes();
		//var_dump($attributes);
		$output = in_array($attrName,array_unique(array_keys($attributes)));
		return $output;
	}


	if( is_product() &&  whatAttr('pa_artusi-built-in-bbq-1400mm') ) { ?>
	<script>
		//1400MM
		//const all = document.querySelector('.variations tr:has(td):has(select:not(#pa_style))');
		/** Fridge option **/
		window.addEventListener('load', function(){
			//Style
			const style = document.querySelector('#pa_style')
			const styleParent = style.parentElement.parentElement
			
			const stoneFinish = document.querySelector('#pa_stone-finish')
			const stoneFinishParent = stoneFinish.parentElement.parentElement
			
			const imageBlack = document.querySelector('#pa_stone-finish+ul .image-variable-item-imperia-black')
			const imageGrey = document.querySelector('#pa_stone-finish+ul .image-variable-item-cosmopolita-grey')
			const imageTorano = document.querySelector('#pa_stone-finish+ul .image-variable-item-torano-statuario')
			
			var bbq = document.querySelector('#pa_artusi-built-in-bbq-1400mm')
			var bbqParent = bbq.parentElement.parentElement
			
			const beverage = document.querySelector('#pa_artusi-beverage-centre')
			const beverageParent = beverage.parentElement.parentElement
			
			const fridgeFinish = document.querySelector('#pa_finish')
			const fridgeFinishParent = fridgeFinish.parentElement.parentElement
					
			const snglCube = document.querySelector('#pa_single-cube-qbe-1400')
			const snglCubeParent = snglCube.parentElement.parentElement
			
			const dblCube = document.querySelector('#pa_double-cube-qbe')
			const dblCubeParent = dblCube.parentElement.parentElement
			

		   jQuery(function ($) {
		        $(document).ready(function () {          
					
          			var p_1 = getURLParameters("attribute_pa_style");
          			var p_2 = getURLParameters("attribute_pa_stone-finish");
          			var p_3 = getURLParameters("attribute_pa_artusi-built-in-bbq-1400mm");
          			var p_4 = getURLParameters("attribute_pa_artusi-beverage-centre");
          			var p_5 = getURLParameters("attribute_pa_finish");
          			var p_6 = getURLParameters("attribute_pa_single-cube-qbe-1400");
          			var p_7 = getURLParameters("attribute_pa_double-cube-qbe");

          			$( '.variations tr' ).each(function(){
          				option = $(this).find( 'option' );
          				$(option).each(function(){
					        if($(this).val() == p_1){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_1+'"])').css('display', 'table-row');
					        }
					        if($(this).val() == p_2){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_2+'"])').css('display', 'table-row');
					        }
					        if($(this).val() == p_3){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_3+'"])').css('display', 'table-row');
					        }
					        if($(this).val() == p_4){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_4+'"])').css('display', 'table-row');
					        }
					        if($(this).val() == p_5){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_5+'"])').css('display', 'table-row');
					        }
					        if($(this).val() == p_6){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_6+'"])').css('display', 'table-row');
					        }
					        if($(this).val() == p_7){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_7+'"])').css('display', 'table-row');
					        }
          				});


          			});

		    	});
				//Get URL PARAMETER
				function getURLParameters(paramName) {
				    var sURL = window.document.URL.toString();
				    if (sURL.indexOf("?") > 0) {
				        var arrParams = sURL.split("?");
				        var arrURLParams = arrParams[1].split("&");
				        var arrParamNames = new Array(arrURLParams.length);
				        var arrParamValues = new Array(arrURLParams.length);

				        var i = 0;
				        for (i = 0; i < arrURLParams.length; i++) {
				            var sParam = arrURLParams[i].split("=");
				            arrParamNames[i] = sParam[0];
				            if (sParam[1] != "") arrParamValues[i] = unescape(sParam[1]);
				            else arrParamValues[i] = "No Value";
				        }

				        for (i = 0; i < arrURLParams.length; i++) {
				            if (arrParamNames[i] == paramName) {
				                //alert("Parameter:" + arrParamValues[i]);
				                return arrParamValues[i];
				            }
				        }
				        return "No Parameters Found";
				    }
				}
		    });




			//Remove Tick to the Stone Finish 
			//to set it to none by default
			style.addEventListener('input', function(){
				if(this.value != '') {
					stoneFinishParent.style.display = 'table-row'
					//Remove Tick to the Stone Finish 
					//to set it to none by default
					setTimeout(function(){
						imageBlack.classList.remove('selected');
						if (!imageBlack.classList.contains('selected')) {
							//clickMe(imageBlack);
							imageBlack.classList.remove('selected');
						}
					},200);
					jQuery(function($) {
						$(document).ready(function() {
							$( imageBlack ).click(function(){
								if ( !$(this).hasClass('selected') ) {
									$(bbqParent).show();
									$(beverageParent).show();
								} else {
									$(bbqParent).hide();
									$(beverageParent).hide();
								}
							});
							$( imageGrey ).click(function(){
								if ( !$(this).hasClass('selected') ) {
									$(bbqParent).show();
									$(beverageParent).show();
								} else {
									$(bbqParent).hide();
									$(beverageParent).hide();
								}
							});
							$( imageTorano ).click(function(){
								if ( !$(this).hasClass('selected') ) {
									$(bbqParent).show();
									$(beverageParent).show();
								} else {
									$(bbqParent).hide();
									$(beverageParent).hide();
								}
							});
						});
					});
				} else {
					stoneFinishParent.style.display = 'none'
					bbqParent.style.display = 'none'
					beverageParent.style.display = 'none'
					all.style.display = 'none'
					//clickMe(imageBlack);
				}
			})
			
			beverage.addEventListener('input', function(){
				if(this.value == 'single-door') {
					fridgeFinishParent.style.display = 'table-row'
					snglCubeParent.style.display = 'table-row'
					dblCubeParent.style.display = 'none'

					//Reset value to none
					dblCube.value = 'none';
				} else if ( this.value == 'none'  ) {
					dblCubeParent.style.display = 'table-row'
					fridgeFinishParent.style.display = 'none'
					snglCubeParent.style.display = 'none'

					//Reset value to none
					snglCube.value = 'none'

				} else {
					dblCubeParent.style.display = 'none'
					fridgeFinishParent.style.display = 'none'
					snglCubeParent.style.display = 'none'

					//Reset value to none
					snglCube.value = 'none'
				}
			})
			

		})
	</script>
	<?php
	} elseif ( is_product() &&  whatAttr('pa_artusi-built-in-bbq-1900mm') ) { ?>

	<script>
		function triggerVariationChange() {
			jQuery(function($) {
			    $(document).ready(function() {
			    	setTimeout(function(){
			    		$('.variations select').trigger('change');
			    	}, 50);
			    });
			});
		}
		
		//Trigger variaton change on load.
		triggerVariationChange();

		//1900MM
		//DEV NOTE: The NONE value from Black Finish (ABBQM) and Stainless Finish (ABBQ1B) dropdown is hidden using CSS
		/** Fridge option **/
		window.addEventListener('load', function(){
			//Style
			const style = document.querySelector('#pa_style');
			const styleParent = style.parentElement.parentElement;
			
			const stoneFinish = document.querySelector('#pa_stone-finish');
			const stoneFinishParent = stoneFinish.parentElement.parentElement;
			
			const imageBlack = document.querySelector('#pa_stone-finish+ul .image-variable-item-imperia-black')
			const imageGrey = document.querySelector('#pa_stone-finish+ul .image-variable-item-cosmopolita-grey')
			const imageTorano = document.querySelector('#pa_stone-finish+ul .image-variable-item-torano-statuario')
			
			const bbq = document.querySelector('#pa_artusi-built-in-bbq-1900mm');
			const bbqParent = bbq.parentElement.parentElement;
			
			const upgrades = document.querySelector('#pa_upgrades-1900mm');
			const upgradesParent = upgrades.parentElement.parentElement;
			
			const fridge = document.querySelector('#pa_fridge-1900mm');
			const fridgeParent = fridge.parentElement.parentElement;
			
			const bbq3burner = document.querySelector('#pa_bbq-combinations-abbqm2');
			const bbq3burnerParent = bbq3burner.parentElement.parentElement;

			const bbqFinish = document.querySelector('#pa_bbq-finish-with-4-burner');
			const bbqFinishParent = bbqFinish.parentElement.parentElement;
			
			const bbqFinishBlack = document.querySelector('#pa_bbq-finish-with-4-burner+ul li.image-variable-item-black');
				const aqq1b = document.querySelector('#pa_bbq-combinations-abbq1b');
				const aqq1bParent = aqq1b.parentElement.parentElement;
				
			const bbqFinishSteel = document.querySelector('#pa_bbq-finish-with-4-burner+ul li.image-variable-item-stainless-steel');
				const abbqm = document.querySelector('#pa_bbq-combinations-abbqm');
				const abbqmParent = abbqm.parentElement.parentElement;

			const defaultFinish = document.querySelector('#pa_bbq-finish-with-4-burner+ul li.image-variable-item-none');
			
			const fridgeFinish = document.querySelector('#pa_fridge-finish-1900mm');
			const fridgeFinishParent = fridgeFinish.parentElement.parentElement;

			const defaultFridgeFinish = document.querySelector('#pa_fridge-finish-1900mm+ul li.image-variable-item-none');
			const blackFridgeFinish = document.querySelector('#pa_fridge-finish-1900mm+ul li.image-variable-item-black-abc1b');

			const dblCube = document.querySelector('#pa_double-cube-qbe');
			const dblCubeParent = dblCube.parentElement.parentElement;
			
			const tripleCube = document.querySelector('#pa_triple-cube-qbe-1900');
			const tripleCubeCubeParent = tripleCube.parentElement.parentElement;


			jQuery(function ($) {
		        $(document).ready(function () {          
					
          			var p_1 = getURLParameters("attribute_pa_style");
          			var p_2 = getURLParameters("attribute_pa_stone-finish");
          			var p_3 = getURLParameters("attribute_pa_artusi-built-in-bbq-1900mm");
          			var p_4 = getURLParameters("attribute_pa_upgrades-1900mm");
          			var p_5 = getURLParameters("attribute_pa_fridge-1900mm");
          			var p_6 = getURLParameters("attribute_pa_bbq-combinations-abbqm2");
          			var p_7 = getURLParameters("attribute_pa_bbq-finish-with-4-burner");
          			var p_8 = getURLParameters("attribute_pa_bbq-combinations-abbq1b");
          			var p_9 = getURLParameters("attribute_pa_bbq-combinations-abbqm");
          			var p_10 = getURLParameters("attribute_pa_fridge-finish-1900mm");
          			var p_11 = getURLParameters("attribute_pa_double-cube-qbe");
          			var p_12 = getURLParameters("attribute_pa_triple-cube-qbe-1900");

          			$( '.variations tr' ).each(function(){
          				option = $(this).find( 'option' );
          				$(option).each(function(){
					        if($(this).val()==p_1){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_1+'"])').css('display', 'table-row');
					        }
					        if($(this).val()==p_2){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_2+'"])').css('display', 'table-row');
					        }
					        if($(this).val()==p_3){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_3+'"])').css('display', 'table-row');
					        }
					        if($(this).val()==p_4){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_4+'"])').css('display', 'table-row');
					        }
					        if($(this).val()==p_5){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_5+'"])').css('display', 'table-row');
					        }
					        if($(this).val()==p_6){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_6+'"])').css('display', 'table-row');
					        }
					        if($(this).val()==p_7){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_7+'"])').css('display', 'table-row');
					        }
					        if($(this).val()==p_8){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_8+'"])').css('display', 'table-row');
					        }
					        if($(this).val()==p_9){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_9+'"])').css('display', 'table-row');
					        }
					        if($(this).val()==p_10){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_10+'"])').css('display', 'table-row');
					        }
					        if($(this).val()==p_11){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_11+'"])').css('display', 'table-row');
					        }
					        if($(this).val()==p_12){
          						$('.variations tr:has(td):has(select):has(option[value="'+p_12+'"])').css('display', 'table-row');
					        }
          				});
          			});
		    	});

				//Get URL PARAMETER
				function getURLParameters(paramName) {
				    var sURL = window.document.URL.toString();
				    if (sURL.indexOf("?") > 0) {
				        var arrParams = sURL.split("?");
				        var arrURLParams = arrParams[1].split("&");
				        var arrParamNames = new Array(arrURLParams.length);
				        var arrParamValues = new Array(arrURLParams.length);

				        var i = 0;
				        for (i = 0; i < arrURLParams.length; i++) {
				            var sParam = arrURLParams[i].split("=");
				            arrParamNames[i] = sParam[0];
				            if (sParam[1] != "") arrParamValues[i] = unescape(sParam[1]);
				            else arrParamValues[i] = "No Value";
				        }

				        for (i = 0; i < arrURLParams.length; i++) {
				            if (arrParamNames[i] == paramName) {
				                //alert("Parameter:" + arrParamValues[i]);
				                return arrParamValues[i];
				            }
				        }
				        return "No Parameters Found";
				    }
				}
		    });



				style.addEventListener('input', function(){
				if(this.value !== '') {
					stoneFinishParent.style.display = 'table-row';
					tripleCubeCubeParent.style.display = 'table-row';
					if (!imageBlack.classList.contains('selected')) {
						bbqParent.style.display = 'none';
						upgradesParent.style.display = 'none';
						fridgeParent.style.display = 'none';
						bbq3burnerParent.style.display = 'none';
					} else {
						bbqParent.style.display = 'table-row';
						upgradesParent.style.display = 'table-row';
						fridgeParent.style.display = 'table-row';
						bbq3burnerParent.style.display = 'table-row';
					}
					//Remove Tick to the Stone Finish 
					//to set it to none by default
					setTimeout(function(){
						imageBlack.classList.remove('selected');
						if (!imageBlack.classList.contains('selected')) {
							//clickMe(imageBlack);
							imageBlack.classList.remove('selected');
						}
					},200);
					jQuery(function($) {
						$(document).ready(function() {
							$( imageBlack ).click(function(){
								if ( !$(this).hasClass('selected') ) {
									$(bbqParent).show();
									$(upgradesParent).show();
									$(fridgeParent).show();
									$(bbq3burnerParent).show();
								} else {
									$(bbqParent).hide();
									$(upgradesParent).hide();
									$(fridgeParent).hide();
									$(bbq3burnerParent).hide();
								}
							});
							$( imageGrey ).click(function(){
								if ( !$(this).hasClass('selected') ) {
									$(bbqParent).show();
									$(upgradesParent).show();
									$(fridgeParent).show();
									$(bbq3burnerParent).show();
								} else {
									$(bbqParent).hide();
									$(upgradesParent).hide();
									$(fridgeParent).hide();
									$(bbq3burnerParent).hide();
								}
							});
							$( imageTorano ).click(function(){
								if ( !$(this).hasClass('selected') ) {
									$(bbqParent).show();
									$(upgradesParent).show();
									$(fridgeParent).show();
									$(bbq3burnerParent).show();
								} else {
									$(bbqParent).hide();
									$(upgradesParent).hide();
									$(fridgeParent).hide();
									$(bbq3burnerParent).hide();
								}
							});
						});
					});

				} else {
					stoneFinishParent.style.display = 'none';
					bbqParent.style.display = 'none';
					upgradesParent.style.display = 'none';
					fridgeParent.style.display = 'none';
					bbq3burnerParent.style.display = 'none';
					bbqFinishParent.style.display = 'none'
					aqq1bParent.style.display = 'none'
					abbqmParent.style.display = 'none'
					tripleCubeCubeParent.style.display = 'none';


					//clickMe(defaultFinish);
					aqq1b.value = 'no-lid';
					abbqm.value = 'no-lid';
				}
			});
						
			
			bbq.addEventListener('input', function(){
				if( this.value === '3-burner' ) {
					bbq3burnerParent.style.display = 'table-row';

					bbqFinishParent.style.display = 'none';
					aqq1bParent.style.display = 'none';
					abbqmParent.style.display = 'none';
					fridgeFinishParent.style.display = 'none';

					aqq1b.value = 'no-lid';
					abbqm.value = 'no-lid';
					bbq3burner.value = 'no-lid';
					fridge.value = 'no-fridge';
					dblCube.value = 'none';
					tripleCube.value = 'none';
					//Click Default Finish
					clickMe(defaultFinish);
				} else if ( this.value === '4-burner' ) {
					bbq3burnerParent.style.display = 'none';
					bbqFinishParent.style.display = 'table-row';

					//Click Default Finish
					clickMe(defaultFinish);
					fridgeFinishParent.style.display = 'none';
					fridge.value = 'no-fridge';
					bbq3burner.value = 'none';
					dblCube.value = 'none';
					tripleCube.value = 'none';
						//Steel and Black
						bbqFinishBlack.onclick = function(){
							aqq1bParent.style.display = 'table-row';
							abbqmParent.style.display = 'none';

							//Trigger variation change so the label will also change
							triggerVariationChange();
							aqq1b.value	= 'no-lid';
							abbqm.value	= 'no-lid';
							//End of Trigger

						}

						bbqFinishSteel.onclick = function(){
							aqq1bParent.style.display = 'none';
							abbqmParent.style.display = 'table-row';

							//Trigger variation change so the label will also change
							triggerVariationChange();
							aqq1b.value	= 'no-lid';
							abbqm.value	= 'no-lid';
							//End of Trigger
						}
				} else {
					bbq3burnerParent.style.display = 'none';
					bbqFinishParent.style.display = 'none';

					aqq1bParent.style.display = 'none';
					abbqmParent.style.display = 'none';

					aqq1b.value = 'no-lid';
					abbqm.value = 'no-lid';
					bbq3burner.value = 'no-lid';

					//Click Default Finish
					clickMe(defaultFinish);
					fridge.value = 'no-fridge';
					dblCube.value = 'none';
					tripleCube.value = 'none';
				}
			});

			upgrades.addEventListener('input', function(){
				if( this.value === 'none' ) {
					fridgeParent.style.display = 'table-row';
					fridge.value = 'no-fridge';

					clickMe(defaultFridgeFinish);
				} else if ( this.value === '300-gas-cooktop-cagh32x' ) {
					fridgeParent.style.display = 'none';
					fridgeFinishParent.style.display = 'none';

					fridge.value = 'no-fridge';

					clickMe(defaultFridgeFinish);
				} else if ( this.value === '380-wok-cooktop-agh41b' ) {
					fridgeParent.style.display = 'none';
					fridgeFinishParent.style.display = 'none';

					fridge.value = 'no-fridge';

					clickMe(defaultFridgeFinish);
				} else {
					fridgeParent.style.display = 'none';
					fridgeFinishParent.style.display = 'none';

					fridge.value = 'no-fridge';

					clickMe(defaultFridgeFinish);
				}
			});
			
			
			fridge.addEventListener('input', function(){
				if( this.value === 'no-fridge' ) {
					fridgeFinishParent.style.display = 'none';
					dblCubeParent.style.display = 'none';
					tripleCubeCubeParent.style.display = 'table-row';

					//Reset Value
					tripleCube.value = 'none';
					dblCube.value = 'none';
					clickMe(defaultFridgeFinish);
				} else if ( this.value === 'fridge' ) {
					fridgeFinishParent.style.display = 'table-row';
					dblCubeParent.style.display = 'table-row';
					tripleCubeCubeParent.style.display = 'none';

					//Reset Value
					tripleCube.value = 'none';
					//clickMe(blackFridgeFinish);
					setTimeout(function(){
						if (!blackFridgeFinish.classList.contains('selected')) {
							clickMe(blackFridgeFinish);
						}
					},200);
				} else {
					fridgeFinishParent.style.display = 'none';
					dblCubeParent.style.display = 'none';
					tripleCubeCubeParent.style.display = 'none';

					//Reset Value
					tripleCube.value = 'none';
					clickMe(defaultFridgeFinish);
				}
			});
			
		});
	</script>

	<?php
	} elseif ( is_product() && whatAttr('pa_built-in-bbq-finish-2400mm') ) { ?>
	<script>
		//Style
		//2400MM		
		const style = document.querySelector('#pa_style');
		const styleParent = style.parentElement.parentElement;

		const stoneFinish = document.querySelector('#pa_stone-finish')
		const stoneFinishParent = stoneFinish.parentElement.parentElement;

		const imageBlack = document.querySelector('#pa_stone-finish+ul .image-variable-item-imperia-black')
		const imageGrey = document.querySelector('#pa_stone-finish+ul .image-variable-item-cosmopolita-grey')
		const imageTorano = document.querySelector('#pa_stone-finish+ul .image-variable-item-torano-statuario')

		const bbqFinish = document.querySelector('#pa_built-in-bbq-finish-2400mm')
		const bbqFinishParent = bbqFinish.parentElement.parentElement;

		const bbqImageBlack = document.querySelector('#pa_built-in-bbq-finish-2400mm+ul .image-variable-item-black')
		const bbqImageSteel = document.querySelector('#pa_built-in-bbq-finish-2400mm+ul .image-variable-item-stainless-steel')

		//Black
		const abbq1 = document.querySelector('#pa_bbq-combinations-abbq1b')
		const abbq1Parent = abbq1.parentElement.parentElement;

		//Steel
		const abbqm = document.querySelector('#pa_bbq-combinations-abbqm')
		const abbqmParent = abbqm.parentElement.parentElement;

		const upgrades = document.querySelector('#pa_upgrades-2400mm')
		const upgradesParent = upgrades.parentElement.parentElement;

		const fridgeNoUpgrades = document.querySelector('#pa_fridge-2400mm')
		const fridgeNoUpgradesParent = fridgeNoUpgrades.parentElement.parentElement;


		//For Upgrades = None
		const cubBoard = document.querySelector('#pa_cupboard-2400mm')
		const cubBoardParent = cubBoard.parentElement.parentElement;

		const cubeTriple = document.querySelector('#pa_cube-2400mm-qbe-triple')
		const cubeTripleParent = cubeTriple.parentElement.parentElement;

		//For Upgrades = Sink & Top
		const fridgeUpgrades = document.querySelector('#pa_fridge-with-upgrades-2400mm')
		const fridgeUpgradesParent = fridgeUpgrades.parentElement.parentElement;


		const sinktopFinish = document.querySelector('#pa_sink-tap-finish')
		const sinktopFinishParent = sinktopFinish.parentElement.parentElement;

		const sinktopFinishBlack = document.querySelector('#pa_sink-tap-finish+ul .image-variable-item-black')

		//For Upgrades = 300 Cooktop
		const cooktopFinish = document.querySelector('#pa_cooktop-finish-2400mm')
		const cooktopFinishParent = cooktopFinish.parentElement.parentElement;

		const cooktopFinishSteel = document.querySelector('#pa_cooktop-finish-2400mm+ul .image-variable-item-stainless-steel')

		//Fridge Finish
		const fridgeFinish = document.querySelector('#pa_fridge-finish-2400mm')
		const fridgeFinishParent = fridgeFinish.parentElement.parentElement;

		//Single Cube
		// const singleCube = document.querySelector('#pa_single-cube-qbe-1400')
		// const singleCubeParent = singleCube.parentElement.parentElement;
		
		const doubleCube = document.querySelector('#pa_cube-2400mm-qbe-double')
		const doubleCubeParent = doubleCube.parentElement.parentElement;
		

	   jQuery(function ($) {
	        $(document).ready(function () {
      			var p_1 = getURLParameters("attribute_pa_style");
      			var p_2 = getURLParameters("attribute_pa_stone-finish");
      			var p_3 = getURLParameters("attribute_pa_built-in-bbq-finish-2400mm");
      			var p_4 = getURLParameters("attribute_pa_bbq-combinations-abbq1b");
      			var p_5 = getURLParameters("attribute_pa_bbq-combinations-abbqm");
      			var p_6 = getURLParameters("attribute_pa_upgrades-2400mm");
      			var p_7 = getURLParameters("attribute_pa_fridge-2400mm");
      			var p_8 = getURLParameters("attribute_pa_cupboard-2400mm");
      			var p_9 = getURLParameters("attribute_pa_cube-2400mm-qbe-triple");
      			var p_10 = getURLParameters("attribute_pa_fridge-with-upgrades-2400mm");
      			var p_11 = getURLParameters("attribute_pa_sink-tap-finish");
      			var p_12 = getURLParameters("attribute_pa_cooktop-finish-2400mm");
      			var p_13 = getURLParameters("attribute_pa_fridge-finish-2400mm");
      			var p_14 = getURLParameters("attribute_pa_single-cube-qbe-1400");
      			var p_15 = getURLParameters("attribute_pa_cube-2400mm-qbe-double");

      			$( '.variations tr' ).each(function(){
      				option = $(this).find( 'option' );
      				$(option).each(function(){
				        if($(this).val()==p_1){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_1+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_2){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_2+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_3){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_3+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_4){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_4+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_5){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_5+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_6){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_6+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_7){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_7+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_8){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_8+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_9){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_9+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_10){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_10+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_11){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_11+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_12){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_12+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_13){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_12+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_14){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_12+'"])').css('display', 'table-row');
				        }
				        if($(this).val()==p_15){
      						$('.variations tr:has(td):has(select):has(option[value="'+p_12+'"])').css('display', 'table-row');
				        }
      				});
      			});
	    	});

			//Get URL PARAMETER
			function getURLParameters(paramName) {
			    var sURL = window.document.URL.toString();
			    if (sURL.indexOf("?") > 0) {
			        var arrParams = sURL.split("?");
			        var arrURLParams = arrParams[1].split("&");
			        var arrParamNames = new Array(arrURLParams.length);
			        var arrParamValues = new Array(arrURLParams.length);

			        var i = 0;
			        for (i = 0; i < arrURLParams.length; i++) {
			            var sParam = arrURLParams[i].split("=");
			            arrParamNames[i] = sParam[0];
			            if (sParam[1] != "") arrParamValues[i] = unescape(sParam[1]);
			            else arrParamValues[i] = "No Value";
			        }

			        for (i = 0; i < arrURLParams.length; i++) {
			            if (arrParamNames[i] == paramName) {
			                //alert("Parameter:" + arrParamValues[i]);
			                return arrParamValues[i];
			            }
			        }
			        return "No Parameters Found";
			    }
			}
    	});


		style.addEventListener('input', function(){
			if(this.value !== '') {
				stoneFinishParent.style.display = 'table-row';
				bbqFinishParent.style.display = 'table-row';
				//Remove Tick to the Stone Finish 
				//to set it to none by default
				setTimeout(function(){
					if (!imageBlack.classList.contains('selected')) {
						//clickMe(imageBlack);
						imageBlack.classList.remove('selected');
					}
				},200);
				jQuery(function($) {
					$(document).ready(function() {
						//Stone Finish
						$( imageBlack ).click(function(){
							if ( !$(this).hasClass('selected') ) {
								$(bbqFinishParent).show();
							} else {
								$(bbqFinishParent).hide();
								$(abbq1Parent).hide();
								$(abbqmParent).hide();
							}
						});
						$( imageGrey ).click(function(){
							if ( !$(this).hasClass('selected') ) {
								$(bbqFinishParent).show();
							} else {
								$(bbqFinishParent).hide();
								$(abbq1Parent).hide();
								$(abbqmParent).hide();
							}
						});
						$( imageTorano ).click(function(){
							if ( !$(this).hasClass('selected') ) {
								$(bbqFinishParent).show();
							} else {
								$(bbqFinishParent).show();
								$(abbq1Parent).hide();
								$(abbqmParent).hide();
							}
						});

						//BBQ Finish
						$( bbqImageBlack ).click(function(){
							if ( !$(this).hasClass('selected') ) {
								$(abbq1Parent).show();
								$(upgradesParent).show();
								$(abbqmParent).hide();
								abbqm.value = 'no-lid';
								abbq1.value = 'no-lid';
							} else {
								$(abbq1Parent).hide();
								$(upgradesParent).hide();
								abbqm.value = 'no-lid';
								abbq1.value = 'no-lid';
							}
						});
						$( bbqImageSteel ).click(function(){
							if ( !$(this).hasClass('selected') ) {
								$(abbqmParent).show();
								$(upgradesParent).show();
								$(abbq1Parent).hide();
								abbqm.value = 'no-lid';
								abbq1.value = 'no-lid';
							} else {
								$(abbqmParent).hide();
								$(upgradesParent).hide();
								abbqm.value = 'no-lid';
								abbq1.value = 'no-lid';
							}
						});
					});
				});

			} else {
				stoneFinishParent.style.display = 'none';
				bbqFinishParent.style.display = 'none';
				abbqmParent.style.display = 'none';
				abbq1Parent.style.display = 'none';
				all.style.display = 'none'

				//clickMe(imageBlack);

			}
		});

		abbq1.addEventListener('input', function(){
			if(this.value !== '') {
				upgradesParent.style.display = 'table-row';
			} else {
				upgradesParent.style.display = 'none';
			}
		});

		abbqm.addEventListener('input', function(){
			if(this.value !== '') {
				upgradesParent.style.display = 'table-row';
			} else {
				upgradesParent.style.display = 'none';
			}
		});

		//UPGRADES
		upgrades.addEventListener('input', function(){
			if( this.value == 'none' ) {
				fridgeNoUpgradesParent.style.display = 'table-row';
				cubBoardParent.style.display = 'table-row';

				sinktopFinishParent.style.display = 'none';
				fridgeUpgradesParent.style.display = 'none';
				cooktopFinishParent.style.display = 'none';

				//When extra fields are open
				fridgeFinishParent.style.display = 'none';
				// singleCubeParent.style.display = 'none';
				doubleCubeParent.style.display = 'none';

				//Set to default none value
				fridgeUpgrades.value = 'none';
				fridgeNoUpgrades.value = 'none';
				// singleCube.value = 'none';
				doubleCube.value = 'none';
				cubeTriple.value = 'none';
				cubBoard.value = 'no';
			} else if ( this.value == 'sink-tap' ) {
				sinktopFinishParent.style.display = 'table-row';
				fridgeUpgradesParent.style.display = 'table-row';

				fridgeNoUpgradesParent.style.display = 'none';
				cubBoardParent.style.display = 'none';

				//When extra fields are open
				cooktopFinishParent.style.display = 'none';
				fridgeFinishParent.style.display = 'none';
				// singleCubeParent.style.display = 'none';
				doubleCubeParent.style.display = 'none';

				//Set to default none value
				fridgeUpgrades.value = 'none';
				fridgeNoUpgrades.value = 'none';
				// singleCube.value = 'none';
				doubleCube.value = 'none';
				cubeTriple.value = 'none';
				cubBoard.value = 'no';
				setTimeout(function(){
					if (!sinktopFinishBlack.classList.contains('selected')) {
						clickMe(sinktopFinishBlack);
					}
					if (!cooktopFinishSteel.classList.contains('selected')) {
						clickMe(cooktopFinishSteel);
					}
				},200);
			} else if ( this.value == '300-cooktop' ) {
				cooktopFinishParent.style.display = 'table-row';
				fridgeUpgradesParent.style.display = 'table-row';

				sinktopFinishParent.style.display = 'none';
				fridgeNoUpgradesParent.style.display = 'none';
				cubBoardParent.style.display = 'none';
				cubeTripleParent.style.display = 'none';

				//When extra fields are open
				fridgeFinishParent.style.display = 'none';
				// singleCubeParent.style.display = 'none';
				doubleCubeParent.style.display = 'none';

				//Set to default none value
				fridgeUpgrades.value = 'none';
				fridgeNoUpgrades.value = 'none';
				// singleCube.value = 'none';
				doubleCube.value = 'none';
				cubeTriple.value = 'none';
				cubBoard.value = 'no';
				setTimeout(function(){
					if (!sinktopFinishBlack.classList.contains('selected')) {
						clickMe(sinktopFinishBlack);
					}
					if (!cooktopFinishSteel.classList.contains('selected')) {
						clickMe(cooktopFinishSteel);
					}
				},200);

			} else if ( this.value == '380-wok-burner-agh41b' ) {
				fridgeUpgradesParent.style.display = 'table-row';
				cubeTripleParent.style.display = 'table-row';

				cooktopFinishParent.style.display = 'none';
				sinktopFinishParent.style.display = 'none';
				fridgeNoUpgradesParent.style.display = 'none';
				cubBoardParent.style.display = 'none';

				//When extra fields are open
				fridgeFinishParent.style.display = 'none';
				// singleCubeParent.style.display = 'none';
				doubleCubeParent.style.display = 'none';

				//Set to default none value
				fridgeUpgrades.value = 'none';
				fridgeNoUpgrades.value = 'none';
				// singleCube.value = 'none';
				doubleCube.value = 'none';
				cubeTriple.value = 'none';
				cubBoard.value = 'no';
				setTimeout(function(){
					if (!sinktopFinishBlack.classList.contains('selected')) {
						clickMe(sinktopFinishBlack);
					}
					if (!cooktopFinishSteel.classList.contains('selected')) {
						clickMe(cooktopFinishSteel);
					}
				},200);
			} else {
				//None
				fridgeNoUpgradesParent.style.display = 'none';
				cubBoardParent.style.display = 'none';

				//Sink Top
				sinktopFinishParent.style.display = 'none';
				fridgeUpgradesParent.style.display = 'none';

				//300 Cooktop
				cooktopFinishParent.style.display = 'none';

				//When extra fields are open
				fridgeFinishParent.style.display = 'none';
				// singleCubeParent.style.display = 'none';
				doubleCubeParent.style.display = 'none';

				//Set to default none value
				fridgeUpgrades.value = 'none';
				fridgeNoUpgrades.value = 'none';
				// singleCube.value = 'none';
				doubleCube.value = 'none';
				cubeTriple.value = 'none';
				cubBoard.value = 'no';
				setTimeout(function(){
					if (!sinktopFinishBlack.classList.contains('selected')) {
						clickMe(sinktopFinishBlack);
					}
					if (!cooktopFinishSteel.classList.contains('selected')) {
						clickMe(cooktopFinishSteel);
					}
				},200);
			}
		});

		fridgeNoUpgrades.addEventListener('input', function(){
			if(this.value == 'single-door') {
				fridgeFinishParent.style.display = 'table-row';
				doubleCubeParent.style.display = 'table-row';

				cubBoardParent.style.display = 'none';
				// singleCubeParent.style.display = 'none';
				
				//Set to default none value
				fridgeUpgrades.value = 'none';
				// singleCube.value = 'none';
				doubleCube.value = 'none';
				cubeTriple.value = 'none';
			} else if(this.value == 'double-door') {
				fridgeFinishParent.style.display = 'table-row';
				// singleCubeParent.style.display = 'table-row';

				cubBoardParent.style.display = 'none';
				doubleCubeParent.style.display = 'none';
				
				//Set to default none value
				fridgeUpgrades.value = 'none';
				// singleCube.value = 'none';
				doubleCube.value = 'none';
				cubeTriple.value = 'none';
			} else {
				fridgeFinishParent.style.display = 'none';
				cubBoardParent.style.display = 'none';
				// singleCubeParent.style.display = 'none';
				doubleCubeParent.style.display = 'none';
				
				//Set to default none value
				fridgeUpgrades.value = 'none';
				// singleCube.value = 'none';
				doubleCube.value = 'none';
				cubeTriple.value = 'none';
			}
		});

		fridgeUpgrades.addEventListener('input', function(){
			if(this.value != 'single-door') {
				cubeTripleParent.style.display = 'table-row';

				fridgeFinishParent.style.display = 'none';
				// singleCubeParent.style.display = 'none';

				//Set to default none value
				fridgeNoUpgrades.value = 'none';
				singleCube.value = 'none';
				doubleCube.value = 'none';
				cubeTriple.value = 'none';
			} else {
				fridgeFinishParent.style.display = 'table-row';
				// singleCubeParent.style.display = 'table-row';

				cubeTripleParent.style.display = 'none';

				//Set to default none value
				fridgeNoUpgrades.value = 'none';
				// singleCube.value = 'none';
				doubleCube.value = 'none';
				cubeTriple.value = 'none';
			}
		});

		cubBoard.addEventListener('input', function(){
			if(this.value != 'yes') {
				cubeTripleParent.style.display = 'none';
			} else {
				cubeTripleParent.style.display = 'table-row';
			}
		});

	</script>
	<?php
	}
}
include ('custom-functions.php');